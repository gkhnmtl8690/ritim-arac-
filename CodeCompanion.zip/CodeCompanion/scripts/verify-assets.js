#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const assetsPath = path.join(__dirname, '..', 'client', 'src', 'assets');
const requiredImages = [
  'ankara.png',
  'bursa.jpg', 
  'gelibolu.jpg',
  'izmir.jpeg',
  'karaman.png',
  'sivas.jpg',
  'terazi.png',
  'van.png'
];

console.log('🔍 Türk Müziği Usul Görsellerini Kontrol Ediliyor...\n');

let allPresent = true;

requiredImages.forEach(image => {
  const imagePath = path.join(assetsPath, image);
  if (fs.existsSync(imagePath)) {
    const stats = fs.statSync(imagePath);
    console.log(`✅ ${image} - ${(stats.size / 1024).toFixed(2)} KB`);
  } else {
    console.log(`❌ ${image} - EKSIK!`);
    allPresent = false;
  }
});

if (allPresent) {
  console.log('\n🎉 Tüm usul görselleri mevcut ve kullanıma hazır!');
  console.log('📦 Proje başka ortamlarda sorunsuz çalışacak.');
} else {
  console.log('\n⚠️  Bazı görseller eksik! Proje tam olarak çalışmayabilir.');
  console.log('🔧 Eksik görselleri client/src/assets/ klasörüne ekleyin.');
}

console.log('\n📍 Görsel klasörü:', assetsPath);