# Replit.md

## Overview

This is a full-stack web application built with React frontend and Express backend, featuring a music rhythm pattern application. The application appears to be focused on Turkish musical patterns (usul) with features for creating, editing, and playing rhythmic patterns. It uses modern web technologies including TypeScript, Tailwind CSS, and shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **UI Components**: Comprehensive set of Radix UI primitives wrapped in shadcn/ui

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: tsx for TypeScript execution in development
- **Production**: esbuild for bundling the server code

### Database & ORM
- **Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Schema**: Shared schema definitions between client and server
- **Session Storage**: PostgreSQL session store using connect-pg-simple

## Key Components

### Frontend Components
- **Home Page**: Main application interface for rhythm pattern creation/editing
- **UI Library**: Complete shadcn/ui component set including:
  - Form controls (Button, Input, Select, Checkbox, etc.)
  - Layout components (Card, Dialog, Sheet, etc.)
  - Data display (Table, Chart, Progress, etc.)
  - Navigation (Breadcrumb, Menubar, Pagination, etc.)

### Backend Components
- **Server**: Express.js application with middleware for JSON parsing and logging
- **Routes**: Centralized route registration system
- **Storage**: Abstracted storage interface with in-memory implementation
- **Development**: Vite integration for hot module replacement

### Shared Components
- **Schema**: Drizzle ORM schema definitions
- **Types**: Shared TypeScript types between frontend and backend

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **API Layer**: Express routes handle requests and interact with storage
3. **Data Storage**: Drizzle ORM manages database operations
4. **Response**: Data flows back through the same path with proper error handling

## External Dependencies

### Core Framework Dependencies
- React ecosystem (react, react-dom, react-router via wouter)
- Express.js with TypeScript support
- Vite for build tooling and development server

### UI and Styling
- Tailwind CSS for utility-first styling
- Radix UI primitives for accessible components
- Lucide React for icons
- Class Variance Authority for component variants

### Data Management
- TanStack Query for server state management
- Drizzle ORM for database operations
- Zod for schema validation
- React Hook Form for form management

### Database
- PostgreSQL with Neon Database serverless driver
- connect-pg-simple for session management

### Development Tools
- TypeScript for type safety
- tsx for development execution
- esbuild for production bundling
- Replit-specific development tools

## Deployment Strategy

### Development
- Uses Vite dev server with HMR for frontend
- tsx for running TypeScript server code
- Integrated development environment with Replit tooling

### Production Build
- Frontend: Vite builds optimized static assets
- Backend: esbuild bundles server code for Node.js execution
- Output: Static files in `dist/public`, server bundle in `dist/`

### Database
- PostgreSQL database with environment-based configuration
- Drizzle migrations for schema management
- Session persistence using PostgreSQL store

### Environment Configuration
- Environment variables for database connection
- Separate development and production configurations
- Replit-specific integrations for development environment

The application follows a modern full-stack architecture with clear separation of concerns, type safety throughout, and a focus on developer experience with hot reloading and comprehensive tooling.