import React, { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Play, Pause, Volume2, VolumeX, Repeat, Square, Settings, Music, Library, Edit, Activity, Info, AlertCircle, PlayCircle, Plus, Trash2, Save } from "lucide-react";

// Usul görsel referansları - Bu dosyalar proje ile birlikte taşınır
import izmirImage from "../assets/izmir.jpeg";
import gelibolusImage from "../assets/gelibolu.jpg";
import ankaraImage from "../assets/ankara.png";
import karamanImage from "../assets/karaman.png";
import teraziImage from "../assets/terazi.png";
import vanImage from "../assets/van.png";
import bursaImage from "../assets/bursa.jpg";
import sivasImage from "../assets/sivas.jpg";

// Yeni usul fotoğrafları - attached_assets'den kopyalanan
import ankaraPhoto from "../assets/ankara_1752670402221.png";
import bursaPhoto from "../assets/bursa_1752670402223.jpg";
import gelibolusPhoto from "../assets/gelibolu_1752670402218.jpg";
import izmirPhoto from "../assets/izmir_1752670402219.jpeg";
import karamanPhoto from "../assets/karaman_1752670402222.png";
import sivasPhoto from "../assets/sivas_1752670402224.jpg";
import teraziPhoto from "../assets/terazi_1752670402223.png";
import vanPhoto from "../assets/van_1752670402220.png";

// Sus değeri fotoğrafları
import sekizlikSus from "../assets/sekizlik_sus.png";
import onaltilikSus from "../assets/onaltilik_sus.png";
import dortlukSus from "../assets/dortluk_sus.png";
import ikilikSus from "../assets/ikilik_sus.png";
import birlikSus from "../assets/birlik_sus.jpeg";

// Note types definition
interface NoteType {
  symbol: string;
  duration: number;
  name: string;
}

const noteTypes: Record<string, NoteType> = {
  'quarter': { symbol: '♩', duration: 1.0, name: 'Dörtlük Nota' },
  'eighth': { symbol: '♪', duration: 0.5, name: 'Sekizlik Nota' },
  'sixteenth': { symbol: '𝅘𝅥𝅯', duration: 0.25, name: 'Onaltılık Nota' },
  'dotted-eighth': { symbol: '♪.', duration: 0.75, name: 'Noktalı Sekizlik' }
};

// Usul türleri tanımı - sürüklenebilir usul fotoğrafları
interface UsulType {
  name: string;
  image: string;
  sound: string;
  description: string;
}

const usulTypes: Record<string, UsulType> = {
  'izmir': { name: 'İzmir Usulü', image: izmirPhoto, sound: 'izmir', description: 'Geleneksel İzmir Usulü' },
  'gelibolu': { name: 'Gelibolu Usulü', image: gelibolusPhoto, sound: 'gelibolu', description: 'Geleneksel Gelibolu Usulü' },
  'ankara': { name: 'Ankara Usulü', image: ankaraPhoto, sound: 'ankara', description: 'Geleneksel Ankara Usulü' },
  'karaman': { name: 'Karaman Usulü', image: karamanPhoto, sound: 'karaman', description: 'Geleneksel Karaman Usulü' },
  'terazi': { name: 'Terazi Usulü', image: teraziPhoto, sound: 'terazi', description: 'Geleneksel Terazi Usulü' },
  'van': { name: 'Van Usulü', image: vanPhoto, sound: 'van', description: 'Geleneksel Van Usulü' },
  'bursa': { name: 'Bursa Usulü', image: bursaPhoto, sound: 'bursa', description: 'Geleneksel Bursa Usulü' },
  'sivas': { name: 'Sivas Usulü', image: sivasPhoto, sound: 'sivas', description: 'Geleneksel Sivas Usulü' }
};

// Sus değeri türleri tanımı - sürüklenebilir sus fotoğrafları
interface SusType {
  name: string;
  image: string;
  duration: number;
  description: string;
}

const susTypes: Record<string, SusType> = {
  'sekizlik-sus': { name: 'Sekizlik Sus', image: sekizlikSus, duration: 0.5, description: 'Sekizlik nota değerinde sus' },
  'onaltilik-sus': { name: 'Onaltılık Sus', image: onaltilikSus, duration: 0.25, description: 'Onaltılık nota değerinde sus' },
  'dortluk-sus': { name: 'Dörtlük Sus', image: dortlukSus, duration: 1.0, description: 'Dörtlük nota değerinde sus' },
  'ikilik-sus': { name: 'İkilik Sus', image: ikilikSus, duration: 2.0, description: 'İkilik nota değerinde sus' },
  'birlik-sus': { name: 'Birlik Sus', image: birlikSus, duration: 4.0, description: 'Birlik nota değerinde sus' }
};

const defaultPatterns: Record<string, string[]> = {
  'İzmir': ['eighth', 'eighth'],
  'Gelibolu': ['sixteenth', 'sixteenth', 'sixteenth', 'sixteenth'],
  'Ankara': ['eighth', 'sixteenth', 'sixteenth'],
  'Karaman': ['sixteenth', 'sixteenth', 'eighth'],
  'Terazi': ['sixteenth', 'eighth', 'sixteenth'],
  'Van': ['quarter', 'eighth'],
  'Bursa': ['dotted-eighth', 'sixteenth'],
  'Sivas': ['eighth', 'dotted-eighth']
};

const defaultSyllables: Record<string, string[]> = {
  'İzmir': ['iz', 'mir'],
  'Gelibolu': ['ge', 'li', 'bo', 'lu'],
  'Ankara': ['an', 'ka', 'ra'],
  'Karaman': ['ka', 'ra', 'man'],
  'Terazi': ['te', 'ra', 'zi'],
  'Van': ['van', 'şeh'],
  'Bursa': ['bur', 'sa'],
  'Sivas': ['si', 'vas']
};

interface MeasureType {
  duration: number;
  name: string;
  slots: number;
}

const measureTypes: Record<string, MeasureType> = {
  '2/4': { duration: 2, name: '2/4 (2 vuruş)', slots: 8 },
  '3/4': { duration: 3, name: '3/4 (3 vuruş)', slots: 12 },
  '4/4': { duration: 4, name: '4/4 (4 vuruş)', slots: 16 }
};

// Usul görsel eşleştirmesi - Fallback sistem ile güvenli
const usulImages: Record<string, string> = {
  'İzmir': izmirImage,
  'Gelibolu': gelibolusImage,
  'Ankara': ankaraImage,
  'Karaman': karamanImage,
  'Terazi': teraziImage,
  'Van': vanImage,
  'Bursa': bursaImage,
  'Sivas': sivasImage
};

// Görsel yükleme hatası durumunda fallback
const handleImageError = (event: React.SyntheticEvent<HTMLImageElement>) => {
  const img = event.currentTarget;
  img.style.display = 'none';
  
  // Fallback div göster
  const fallbackDiv = img.parentElement?.querySelector('.fallback-content');
  if (fallbackDiv) {
    (fallbackDiv as HTMLElement).style.display = 'flex';
  }
};

// Audio context management
let globalAudioContext: AudioContext | null = null;

const initializeAudioContext = (): AudioContext | null => {
  try {
    if (!globalAudioContext) {
      globalAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return globalAudioContext;
  } catch (error) {
    console.error('Audio context initialization failed:', error);
    return null;
  }
};

const createClapSound = async (): Promise<void> => {
  try {
    const audioContext = initializeAudioContext();
    if (!audioContext) return;

    // Resume audio context if suspended
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    const bufferSize = audioContext.sampleRate * 0.1;
    const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
    const output = buffer.getChannelData(0);

    // Generate white noise
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = audioContext.createBufferSource();
    whiteNoise.buffer = buffer;

    const bandpass = audioContext.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.value = 1000;

    const gainNode = audioContext.createGain();
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);

    whiteNoise.connect(bandpass);
    bandpass.connect(gainNode);
    gainNode.connect(audioContext.destination);

    whiteNoise.start();
    whiteNoise.stop(audioContext.currentTime + 0.1);
  } catch (error) {
    console.error('Clap sound creation failed:', error);
  }
};

// Usul spesifik ses üretimi - her usul için farklı ses parametreleri
const createUsulSound = async (usulName: string): Promise<void> => {
  try {
    const audioContext = initializeAudioContext();
    if (!audioContext) return;

    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    // Usul-specific sound parameters
    const usulSoundParams: Record<string, { freq: number; type: 'sine' | 'square' | 'sawtooth' | 'triangle'; duration: number }> = {
      'ankara': { freq: 440, type: 'sine', duration: 0.3 },
      'izmir': { freq: 523, type: 'triangle', duration: 0.25 },
      'gelibolu': { freq: 659, type: 'square', duration: 0.2 },
      'karaman': { freq: 349, type: 'sawtooth', duration: 0.35 },
      'terazi': { freq: 784, type: 'sine', duration: 0.15 },
      'van': { freq: 294, type: 'triangle', duration: 0.4 },
      'bursa': { freq: 392, type: 'square', duration: 0.3 },
      'sivas': { freq: 880, type: 'sine', duration: 0.2 }
    };

    const params = usulSoundParams[usulName] || usulSoundParams['ankara'];
    
    const oscillator = audioContext.createOscillator();
    oscillator.type = params.type;
    oscillator.frequency.value = params.freq;

    const gainNode = audioContext.createGain();
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + params.duration);

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.start();
    oscillator.stop(audioContext.currentTime + params.duration);
  } catch (error) {
    console.error('Usul sound creation failed:', error);
  }
};

export default function Home() {
  const [selectedCity, setSelectedCity] = useState('İzmir');
  const [pattern, setPattern] = useState(defaultPatterns['İzmir']);
  const [syllables, setSyllables] = useState(defaultSyllables['İzmir']);
  const [currentBeat, setCurrentBeat] = useState(-1);
  const [tempo, setTempo] = useState(77);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [selectedMeasure, setSelectedMeasure] = useState('2/4');
  const [customStave, setCustomStave] = useState<string[]>([]);
  const [isPlayingCustom, setIsPlayingCustom] = useState(false);
  const [audioStatus, setAudioStatus] = useState('Sistem hazır');
  const [playbackStatus, setPlaybackStatus] = useState('Durduruldu');
  const [errorStatus, setErrorStatus] = useState('Hata yok');

  const timeoutRef = useRef<NodeJS.Timeout[]>([]);

  // Clear all timeouts utility
  const clearAllTimeouts = useCallback(() => {
    timeoutRef.current.forEach(clearTimeout);
    timeoutRef.current = [];
  }, []);

  // Add timeout utility
  const addTimeout = useCallback((timeoutId: NodeJS.Timeout) => {
    timeoutRef.current.push(timeoutId);
  }, []);

  // Update city selection effect
  useEffect(() => {
    setPattern(defaultPatterns[selectedCity]);
    setSyllables(defaultSyllables[selectedCity]);
    setCurrentBeat(-1);
    setIsPlaying(false);
    clearAllTimeouts();
  }, [selectedCity, clearAllTimeouts]);

  // Cleanup effect
  useEffect(() => {
    return () => {
      clearAllTimeouts();
      if (globalAudioContext && globalAudioContext.state !== 'closed') {
        globalAudioContext.close();
      }
    };
  }, [clearAllTimeouts]);

  // Main pattern playback effect
  useEffect(() => {
    if (!isPlaying) {
      clearAllTimeouts();
      setCurrentBeat(-1);
      setPlaybackStatus('Durduruldu');
      return;
    }

    setPlaybackStatus('Oynatılıyor');

    const playPatternSequence = (index: number) => {
      if (!isPlaying) return;

      if (index >= pattern.length) {
        setCurrentBeat(-1);
        if (isLooping) {
          const timeoutId = setTimeout(() => playPatternSequence(0), 200);
          addTimeout(timeoutId);
        } else {
          setIsPlaying(false);
        }
        return;
      }

      setCurrentBeat(index);
      if (!isMuted) {
        createClapSound().catch(error => {
          console.error('Audio playback error:', error);
          setErrorStatus('Ses çalma hatası');
        });
      }

      const duration = noteTypes[pattern[index]].duration * (60 / tempo) * 1000;
      const timeoutId = setTimeout(() => playPatternSequence(index + 1), duration);
      addTimeout(timeoutId);
    };

    try {
      playPatternSequence(0);
    } catch (error) {
      console.error('Pattern playback error:', error);
      setErrorStatus('Ritim oynatma hatası');
      setIsPlaying(false);
    }
  }, [isPlaying, pattern, tempo, isMuted, isLooping, addTimeout]);

  // Handle drag and drop
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>, index: number) => {
    e.preventDefault();
    const noteType = e.dataTransfer.getData("noteType");
    if (noteType && noteTypes[noteType]) {
      const newPattern = [...pattern];
      newPattern[index] = noteType;
      setPattern(newPattern);
    }
  }, [pattern]);

  const handleDragStart = useCallback((e: React.DragEvent<HTMLDivElement>, noteType: string) => {
    e.dataTransfer.setData("noteType", noteType);
  }, []);

  const handleUsulDragStart = useCallback((e: React.DragEvent<HTMLDivElement>, usulKey: string) => {
    e.dataTransfer.setData("usulType", usulKey);
  }, []);

  const handleSusDragStart = useCallback((e: React.DragEvent<HTMLDivElement>, susKey: string) => {
    e.dataTransfer.setData("susType", susKey);
  }, []);

  const handleCustomStaveDrop = useCallback((e: React.DragEvent<HTMLDivElement>, index: number) => {
    e.preventDefault();
    const noteType = e.dataTransfer.getData("noteType");
    const usulType = e.dataTransfer.getData("usulType");
    const susType = e.dataTransfer.getData("susType");
    
    if (noteType && noteTypes[noteType]) {
      const newStave = [...customStave];
      while (newStave.length <= index) {
        newStave.push('');
      }
      newStave[index] = noteType;
      setCustomStave(newStave);
    } else if (usulType && usulTypes[usulType]) {
      // Usul fotoğrafı bırakıldığında ses çal
      createUsulSound(usulType);
      
      // Usul fotoğrafının varsayılan notalarını porteye ekle
      const defaultNotesForUsul = defaultPatterns[usulTypes[usulType].name.replace(' Usulü', '')];
      if (defaultNotesForUsul) {
        const newStave = [...customStave];
        defaultNotesForUsul.forEach((note, noteIndex) => {
          const staveIndex = index + noteIndex;
          while (newStave.length <= staveIndex) {
            newStave.push('');
          }
          newStave[staveIndex] = note;
        });
        setCustomStave(newStave);
      }
    } else if (susType && susTypes[susType]) {
      // Sus fotoğrafı bırakıldığında sessizlik (ses çalmaz)
      const newStave = [...customStave];
      while (newStave.length <= index) {
        newStave.push('');
      }
      newStave[index] = 'sus-' + susType; // Sus türlerini özel işaretleyerek ekle
      setCustomStave(newStave);
    }
  }, [customStave]);

  // Calculate custom stave duration
  const calculateTotalDuration = useCallback(() => {
    return customStave.reduce((total, note) => {
      if (note && noteTypes[note]) {
        return total + noteTypes[note].duration;
      } else if (note && note.startsWith('sus-')) {
        const susKey = note.replace('sus-', '');
        if (susTypes[susKey]) {
          return total + susTypes[susKey].duration;
        }
      }
      return total;
    }, 0);
  }, [customStave]);

  // Play custom stave
  const playCustomStave = useCallback(async () => {
    if (isPlayingCustom) {
      setIsPlayingCustom(false);
      clearAllTimeouts();
      return;
    }

    const totalDuration = calculateTotalDuration();
    const expectedDuration = measureTypes[selectedMeasure].duration;

    if (totalDuration === 0) {
      alert('Uyarı: Portede hiç nota yok!');
      return;
    }

    if (Math.abs(totalDuration - expectedDuration) > 0.01) {
      alert(`Uyarı: Notaların toplam süresi ${totalDuration.toFixed(2)} vuruş. ${expectedDuration} vuruş olmalı!`);
      return;
    }

    const validNotes = customStave.filter(note => note && (noteTypes[note] || note.startsWith('sus-')));
    if (validNotes.length === 0) {
      alert('Uyarı: Geçerli nota bulunamadı!');
      return;
    }

    try {
      // Initialize audio context on user interaction
      const audioContext = initializeAudioContext();
      if (!audioContext) {
        setErrorStatus('Ses sistemi başlatılamadı');
        return;
      }

      if (audioContext.state === 'suspended') {
        await audioContext.resume();
      }

      setIsPlayingCustom(true);

      const playStavePattern = (index: number) => {
        if (!isPlayingCustom) return;

        if (index >= validNotes.length) {
          setIsPlayingCustom(false);
          return;
        }

        const note = validNotes[index];
        let duration = 0;

        if (noteTypes[note]) {
          // Normal nota - ses çal
          if (!isMuted) {
            createClapSound().catch(error => {
              console.error('Custom stave audio error:', error);
              setErrorStatus('Özel ritim ses hatası');
            });
          }
          duration = noteTypes[note].duration * (60 / tempo) * 1000;
        } else if (note.startsWith('sus-')) {
          // Sus değeri - ses çalma, sadece bekle
          const susKey = note.replace('sus-', '');
          if (susTypes[susKey]) {
            duration = susTypes[susKey].duration * (60 / tempo) * 1000;
          }
        }

        if (index < validNotes.length - 1) {
          const timeoutId = setTimeout(() => playStavePattern(index + 1), duration);
          addTimeout(timeoutId);
        } else {
          setTimeout(() => setIsPlayingCustom(false), duration);
        }
      };

      playStavePattern(0);
    } catch (error) {
      console.error('Custom stave playback error:', error);
      setErrorStatus('Özel ritim oynatma hatası');
      setIsPlayingCustom(false);
    }
  }, [isPlayingCustom, customStave, selectedMeasure, calculateTotalDuration, isMuted, tempo, addTimeout, clearAllTimeouts]);

  // Initialize audio context on first play
  const handlePlayPause = useCallback(async () => {
    try {
      const audioContext = initializeAudioContext();
      if (!audioContext) {
        setErrorStatus('Ses sistemi başlatılamadı');
        return;
      }

      if (audioContext.state === 'suspended') {
        await audioContext.resume();
      }

      setAudioStatus('Ses sistemi aktif');
      setErrorStatus('Hata yok');
      setIsPlaying(!isPlaying);
    } catch (error) {
      console.error('Audio initialization error:', error);
      setErrorStatus('Ses sistemi hatası');
    }
  }, [isPlaying]);

  // Clear custom stave
  const clearCustomStave = useCallback(() => {
    setCustomStave([]);
    setIsPlayingCustom(false);
    clearAllTimeouts();
  }, [clearAllTimeouts]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-amber-900 mb-3 flex items-center justify-center gap-3">
            <Music className="w-12 h-12" />
            Türk Müziği Ritim Öğretici
          </h1>
          <p className="text-xl text-amber-700 mb-2">Geleneksel Türk müziği usullerini öğrenin ve pratik yapın</p>
          <div className="flex items-center justify-center gap-2 text-amber-600">
            <Music className="w-5 h-5" />
            <span className="text-sm">İnteraktif ritim eğitimi platformu</span>
          </div>
        </div>

        {/* Main Controls and Rhythm Pattern - Side by Side */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Controls Card */}
          <Card className="shadow-2xl border-amber-200 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100 border-b border-amber-200">
              <CardTitle className="text-2xl text-amber-900 flex items-center gap-3">
                <Settings className="w-6 h-6" />
                Usul Seçimi ve Kontroller
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              {/* Usul Selection and Tempo Controls */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Usul Selection */}
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-amber-800 mb-2">Usul Seçin:</label>
                  <Select value={selectedCity} onValueChange={setSelectedCity}>
                    <SelectTrigger className="w-full p-4 border-2 border-amber-300 focus:border-amber-600 text-lg">
                      <SelectValue placeholder="Usul Seçiniz" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(defaultPatterns).map(city => (
                        <SelectItem key={city} value={city}>{city} Usulü</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {/* Usul Info Card */}
                  <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                    <div className="flex items-center gap-3 mb-2">
                      <Info className="w-4 h-4 text-amber-600" />
                      <span className="font-medium text-amber-800">Seçili Usul: {selectedCity}</span>
                    </div>
                    <p className="text-sm text-amber-700">
                      {pattern.length} vuruşlu usul. {noteTypes[pattern[0]]?.name} notaları ile başlar.
                    </p>
                  </div>
                </div>

                {/* Tempo Control */}
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-amber-800 mb-2">
                    Tempo: <span className="font-bold text-amber-600">{tempo}</span> BPM
                  </label>
                  <div className="space-y-3">
                    <input
                      type="range"
                      min="60"
                      max="180"
                      value={tempo}
                      onChange={(e) => setTempo(Number(e.target.value))}
                      className="w-full h-3 bg-amber-200 rounded-lg appearance-none cursor-pointer"
                      style={{
                        background: `linear-gradient(to right, #D97706 0%, #D97706 ${((tempo - 60) / 120) * 100}%, #FCD34D ${((tempo - 60) / 120) * 100}%, #FCD34D 100%)`
                      }}
                    />
                    <div className="flex justify-between text-sm text-amber-600 font-medium">
                      <span>🐌 Yavaş (60)</span>
                      <span>⚡ Hızlı (180)</span>
                    </div>
                  </div>
                  
                  {/* Tempo Presets */}
                  <div className="flex gap-2 flex-wrap">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setTempo(77)}
                      className="border-amber-300 text-amber-800 hover:bg-amber-100"
                    >
                      Varsayılan
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setTempo(60)}
                      className="border-amber-300 text-amber-800 hover:bg-amber-100"
                    >
                      Yavaş
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setTempo(120)}
                      className="border-amber-300 text-amber-800 hover:bg-amber-100"
                    >
                      Orta
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setTempo(150)}
                      className="border-amber-300 text-amber-800 hover:bg-amber-100"
                    >
                      Hızlı
                    </Button>
                  </div>
                </div>
              </div>

              {/* Playback Controls */}
              <div className="flex flex-wrap gap-4 justify-center items-center p-6 bg-gray-50 rounded-xl border-2 border-gray-200">
                <Button
                  onClick={handlePlayPause}
                  className={`flex items-center gap-3 px-8 py-4 text-white rounded-xl font-semibold text-lg transition-all transform hover:scale-105 shadow-lg ${
                    isPlaying 
                      ? 'bg-red-500 hover:bg-red-600' 
                      : 'bg-green-500 hover:bg-green-600'
                  }`}
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                  <span>{isPlaying ? 'Durdur' : 'Başlat'}</span>
                </Button>
                
                <Button
                  onClick={() => setIsMuted(!isMuted)}
                  className={`flex items-center gap-2 px-6 py-4 text-white rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg ${
                    isMuted 
                      ? 'bg-gray-500 hover:bg-gray-600' 
                      : 'bg-blue-500 hover:bg-blue-600'
                  }`}
                >
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                  <span>{isMuted ? 'Sessiz' : 'Ses'}</span>
                </Button>
                
                <Button
                  onClick={() => setIsLooping(!isLooping)}
                  className={`flex items-center gap-2 px-6 py-4 text-white rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg ${
                    isLooping 
                      ? 'bg-green-500 hover:bg-green-600' 
                      : 'bg-purple-500 hover:bg-purple-600'
                  }`}
                >
                  <Repeat className="w-5 h-5" />
                  <span>Tekrar</span>
                </Button>
                
                <Button
                  onClick={() => {
                    setIsPlaying(false);
                    setIsPlayingCustom(false);
                    clearAllTimeouts();
                  }}
                  className="flex items-center gap-2 px-6 py-4 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg"
                >
                  <Square className="w-5 h-5" />
                  <span>Dur</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Rhythm Pattern Display */}
          <Card className="shadow-2xl border-amber-200 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100 border-b border-amber-200">
              <CardTitle className="text-2xl text-amber-900 flex items-center gap-3">
                <Music className="w-6 h-6" />
                Ritim Kalıbı: {selectedCity} Usulü
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="space-y-6">
                {/* Usul Image Display */}
                <div className="flex justify-center">
                  <div className="w-64 h-40 bg-white rounded-xl border-2 border-amber-200 overflow-hidden shadow-lg relative">
                    <img 
                      src={usulImages[selectedCity]} 
                      alt={`${selectedCity} Usulü notası`}
                      className="w-full h-full object-contain p-4"
                      onError={handleImageError}
                    />
                    {/* Fallback content */}
                    <div className="fallback-content absolute inset-0 flex-col items-center justify-center p-4 hidden">
                      <Music className="w-12 h-12 text-amber-600 mb-2" />
                      <p className="text-amber-800 font-semibold text-center">{selectedCity} Usulü</p>
                      <p className="text-amber-600 text-sm text-center mt-1">Nota görseli yükleniyor...</p>
                    </div>
                  </div>
                </div>
              
              {/* Beat Pattern Display */}
              <div className="bg-gray-50 rounded-xl p-6 border-2 border-gray-200">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">Vuruş Kalıbı</h3>
                <div className="flex justify-center gap-4 flex-wrap">
                  {pattern.map((note, index) => (
                    <div
                      key={index}
                      draggable
                      onDragStart={(e) => handleDragStart(e, note)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => handleDrop(e, index)}
                      className={`flex flex-col items-center p-4 rounded-xl border-2 shadow-md min-w-24 transition-all cursor-pointer ${
                        currentBeat === index 
                          ? 'bg-green-500 border-green-600 text-white scale-110 shadow-lg animate-pulse' 
                          : 'bg-white border-amber-300 hover:border-amber-400 hover:shadow-md'
                      }`}
                    >
                      <div className="text-3xl mb-2">
                        {noteTypes[note].symbol}
                      </div>
                      <div className={`text-sm font-semibold ${currentBeat === index ? 'text-white' : 'text-amber-800'}`}>
                        {syllables[index]}
                      </div>
                      <div className={`text-xs mt-1 ${currentBeat === index ? 'text-green-100' : 'text-amber-600'}`}>
                        {noteTypes[note].name}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        </div>

        {/* Note Types Library */}
        <Card className="shadow-2xl border-amber-200 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100 border-b border-amber-200">
            <CardTitle className="text-2xl text-amber-900 flex items-center gap-3">
              <Library className="w-6 h-6" />
              Nota Türleri Kütüphanesi
            </CardTitle>
            <p className="text-amber-700 mt-2">Aşağıdaki notaları ve usul fotoğraflarını sürükleyerek özel ritminizi oluşturun</p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-8">
              {/* Note Types Section */}
              <div>
                <h3 className="text-lg font-semibold text-amber-900 mb-4">Nota Türleri</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(noteTypes).map(([type, obj]) => (
                    <div
                      key={type}
                      draggable
                      onDragStart={(e) => handleDragStart(e, type)}
                      className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-xl border-2 border-blue-200 text-center cursor-grab hover:shadow-lg transition-all transform hover:scale-105"
                    >
                      <div className="text-3xl mb-2">{obj.symbol}</div>
                      <div className="font-semibold text-blue-800 text-sm">{obj.name}</div>
                      <div className="text-xs text-blue-600 mt-1">{obj.duration} vuruş</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Usul Photos Section */}
              <div>
                <h3 className="text-lg font-semibold text-amber-900 mb-4">Usul Fotoğrafları</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(usulTypes).map(([key, usul]) => (
                    <div
                      key={key}
                      draggable
                      onDragStart={(e) => handleUsulDragStart(e, key)}
                      className="bg-gradient-to-br from-amber-50 to-amber-100 p-3 rounded-xl border-2 border-amber-200 text-center cursor-grab hover:shadow-lg transition-all transform hover:scale-105"
                    >
                      <div className="w-full h-20 mb-2 bg-white rounded-lg overflow-hidden border border-amber-300">
                        <img 
                          src={usul.image} 
                          alt={usul.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="font-semibold text-amber-800 text-sm">{usul.name}</div>
                      <div className="text-xs text-amber-600 mt-1">{usul.description}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sus Değeri Photos Section */}
              <div>
                <h3 className="text-lg font-semibold text-amber-900 mb-4">Sus Değeri Fotoğrafları</h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {Object.entries(susTypes).map(([key, sus]) => (
                    <div
                      key={key}
                      draggable
                      onDragStart={(e) => handleSusDragStart(e, key)}
                      className="bg-gradient-to-br from-gray-50 to-gray-100 p-3 rounded-xl border-2 border-gray-200 text-center cursor-grab hover:shadow-lg transition-all transform hover:scale-105"
                    >
                      <div className="w-full h-20 mb-2 bg-white rounded-lg overflow-hidden border border-gray-300">
                        <img 
                          src={sus.image} 
                          alt={sus.name}
                          className="w-full h-full object-contain p-1"
                        />
                      </div>
                      <div className="font-semibold text-gray-800 text-sm">{sus.name}</div>
                      <div className="text-xs text-gray-600 mt-1">{sus.description}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Custom Stave Creator */}
        <Card className="shadow-2xl border-amber-200 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100 border-b border-amber-200">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl text-amber-900 flex items-center gap-3">
                  <Edit className="w-6 h-6" />
                  Özel Ritim Oluşturucu
                </CardTitle>
                <p className="text-amber-700 mt-2">Kendi ritim kalıbınızı oluşturun</p>
              </div>
              <div className="text-right">
                <div className="text-sm text-amber-700 mb-1">Ölçü Türü:</div>
                <Select value={selectedMeasure} onValueChange={setSelectedMeasure}>
                  <SelectTrigger className="w-48 border-amber-300">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(measureTypes).map(([key, measure]) => (
                      <SelectItem key={key} value={key}>{measure.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            {/* Custom Stave */}
            <div className="bg-gray-50 rounded-xl p-6 mb-6 border-2 border-gray-200">
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Müzik Portesi</h3>
                <div className="text-sm text-gray-600 mb-4">Notaları aşağıdaki boşluklara sürükleyerek yerleştirin</div>
              </div>
              
              {/* Stave Lines */}
              <div className="relative mb-8">
                {[0, 1, 2, 3, 4].map(line => (
                  <div 
                    key={line} 
                    className="absolute w-full h-0.5 bg-gray-400" 
                    style={{ top: `${line * 24 + 16}px` }}
                  />
                ))}
                
                {/* Drop Zones */}
                <div className="relative h-32">
                  <div className="absolute inset-0 flex items-center gap-2 pl-8">
                    {Array.from({ length: measureTypes[selectedMeasure].slots }).map((_, index) => (
                      <div
                        key={index}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => handleCustomStaveDrop(e, index)}
                        onDoubleClick={() => {
                          const newStave = [...customStave];
                          newStave[index] = '';
                          setCustomStave(newStave);
                        }}
                        className="w-12 h-32 border-2 border-dashed border-amber-300 bg-amber-50/50 hover:bg-amber-100/70 transition-colors flex flex-col items-center justify-center cursor-pointer rounded"
                      >
                        {customStave[index] ? (
                          customStave[index].startsWith('sus-') ? (
                            <div className="w-10 h-10 bg-white rounded border overflow-hidden">
                              <img 
                                src={susTypes[customStave[index].replace('sus-', '')].image} 
                                alt={susTypes[customStave[index].replace('sus-', '')].name}
                                className="w-full h-full object-contain"
                              />
                            </div>
                          ) : noteTypes[customStave[index]] ? (
                            <div className="text-4xl text-amber-800 font-bold">
                              {noteTypes[customStave[index]].symbol}
                            </div>
                          ) : (
                            <Plus className="w-6 h-6 text-gray-400" />
                          )
                        ) : (
                          <Plus className="w-6 h-6 text-gray-400" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Duration Display */}
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">
                  Toplam Süre: <span className="font-semibold">{calculateTotalDuration().toFixed(2)}</span> vuruş
                </span>
                <span className="text-gray-600">
                  Hedef: <span className="font-semibold">{measureTypes[selectedMeasure].duration.toFixed(1)}</span> vuruş
                </span>
              </div>
            </div>
            
            {/* Custom Stave Controls */}
            <div className="flex gap-4 justify-center">
              <Button
                onClick={playCustomStave}
                className={`flex items-center gap-3 px-8 py-4 text-white rounded-xl font-semibold transition-all transform hover:scale-105 shadow-lg ${
                  isPlayingCustom 
                    ? 'bg-red-500 hover:bg-red-600' 
                    : 'bg-indigo-500 hover:bg-indigo-600'
                }`}
              >
                {isPlayingCustom ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                <span>{isPlayingCustom ? 'Durdur' : 'Özel Ritmi Çal'}</span>
              </Button>
              
              <Button
                onClick={clearCustomStave}
                className="flex items-center gap-2 px-6 py-4 bg-gray-500 hover:bg-gray-600 text-white rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg"
              >
                <Trash2 className="w-5 h-5" />
                <span>Temizle</span>
              </Button>
              
              <Button
                onClick={() => alert('Kaydetme özelliği yakında eklenecek!')}
                className="flex items-center gap-2 px-6 py-4 bg-green-500 hover:bg-green-600 text-white rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg"
              >
                <Save className="w-5 h-5" />
                <span>Kaydet</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card className="shadow-2xl border-amber-200 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100 border-b border-amber-200">
            <CardTitle className="text-2xl text-amber-900 flex items-center gap-3">
              <Activity className="w-6 h-6" />
              Sistem Durumu
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Audio Status */}
              <div className="bg-green-50 rounded-xl p-6 border-2 border-green-200 text-center">
                <Volume2 className="w-8 h-8 text-green-600 mx-auto mb-3" />
                <div className="font-semibold text-green-800">Ses Sistemi</div>
                <div className="text-sm text-green-600 mt-1">{audioStatus}</div>
              </div>
              
              {/* Playback Status */}
              <div className="bg-blue-50 rounded-xl p-6 border-2 border-blue-200 text-center">
                <PlayCircle className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <div className="font-semibold text-blue-800">Oynatma Durumu</div>
                <div className="text-sm text-blue-600 mt-1">{playbackStatus}</div>
              </div>
              
              {/* Error Status */}
              <div className="bg-gray-50 rounded-xl p-6 border-2 border-gray-200 text-center">
                <AlertCircle className="w-8 h-8 text-gray-600 mx-auto mb-3" />
                <div className="font-semibold text-gray-800">Hata Durumu</div>
                <div className={`text-sm mt-1 ${errorStatus === 'Hata yok' ? 'text-gray-600' : 'text-red-600'}`}>
                  {errorStatus}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer tip */}
        <div className="text-center text-amber-700 text-sm">
          <p>💡 İpucu: Notaları sürükleyip bırakarak hem usulleri hem de özel porteleri düzenleyebilirsiniz!</p>
        </div>
      </div>
    </div>
  );
}
