# Türk Müziği Usul Görselleri

Bu klasör, Türk müziği ritim uygulamasında kullanılan usul görsellerini içermektedir.

## Dosyalar

- `ankara.png` - Ankara usulü nota görseli
- `bursa.jpg` - Bursa usulü nota görseli  
- `gelibolu.jpg` - Gelibolu usulü nota görseli
- `izmir.jpeg` - İzmir usulü nota görseli
- `karaman.png` - Karaman usulü nota görseli
- `sivas.jpg` - Sivas usulü nota görseli
- `terazi.png` - Terazi usulü nota görseli
- `van.png` - Van usulü nota görseli

## Not

Bu görseller proje için gerekli olan usul notasyonlarını göstermektedir. Proje kopyalandığında bu dosyalar da beraber kopyalanacaktır.